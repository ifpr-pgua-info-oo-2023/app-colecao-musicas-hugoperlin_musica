package ifpr.pgua.eic.colecaomusicas.models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class Repositorio {
    
    private ArrayList<Genero> generos;
    private ArrayList<Artista> artistas;

    public Repositorio(){
        generos = new ArrayList<>();
        artistas = new ArrayList<>();
    }

    public String cadastrarGenero(String nome){
        
        Genero genero = new Genero(nome);

        generos.add(genero);
        
        return "Gênero cadastrado";
            
        
    }

    public String cadastrarArtista(String nome, String contato){
        Artista artista = new Artista(nome,contato);

        artistas.add(artista);
        
        return "Artista cadastrado";
    }

}
